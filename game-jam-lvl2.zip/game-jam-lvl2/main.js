var game = new Phaser.Game(800, 600, Phaser.AUTO);
game.state.add('menuState', test.menuState);
game.state.add('lvl1', test.lvl1);
game.state.add('lvl2', test.lvl2);
game.state.add('boss', test.bossLevel);
game.state.add('gameOver', test.gameOver);
game.state.add('win', test.gameWin);
game.state.start('menuState');